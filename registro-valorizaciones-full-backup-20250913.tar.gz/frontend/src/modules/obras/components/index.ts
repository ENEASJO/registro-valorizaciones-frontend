export { default as FormularioObra } from './FormularioObra';
export { default as PlantelProfesional } from './PlantelProfesional';
export { default as DetalleObra } from './DetalleObra';