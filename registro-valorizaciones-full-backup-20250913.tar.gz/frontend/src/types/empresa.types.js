// =================================================================
// TIPOS TYPESCRIPT PARA MÓDULO DE EMPRESAS
// Sistema de Valorizaciones - Frontend
// =================================================================
export default {};
