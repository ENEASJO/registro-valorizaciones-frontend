// =================================================================
// EXTENSIONES TEMPORALES PARA COMPATIBILIDAD CON COMPONENTES
// Sistema de Valorizaciones - Frontend
// =================================================================
export {};
