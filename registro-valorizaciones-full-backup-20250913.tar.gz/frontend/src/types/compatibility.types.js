// =================================================================
// TIPOS TEMPORALES PARA COMPATIBILIDAD CON COMPONENTES LEGACY
// Sistema de Valorizaciones - Frontend  
// =================================================================
export {};
