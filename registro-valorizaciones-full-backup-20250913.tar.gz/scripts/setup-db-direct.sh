#!/bin/bash

echo "🚀 Configurando base de datos Neon con psql..."

# URL de conexión (reemplaza YOUR-PASSWORD con tu password real)
DB_URL="postgresql://neondb_owner:NEON_PASSWORD@NEON_HOST/neondb"

# Verificar si psql está instalado
if ! command -v psql &> /dev/null; then
    echo "❌ psql no está instalado. Instalando..."
    
    # Detectar sistema operativo e instalar
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        sudo apt-get update && sudo apt-get install -y postgresql-client
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        brew install postgresql
    else
        echo "❌ Sistema operativo no soportado. Instala PostgreSQL client manualmente."
        exit 1
    fi
fi

echo "📄 Ejecutando esquema SQL..."

# Ejecutar el archivo SQL
if [ -f "../database/schema.sql" ]; then
    psql "$DB_URL" -f ../database/schema.sql
    
    if [ $? -eq 0 ]; then
        echo "✅ Esquema ejecutado exitosamente!"
    else
        echo "❌ Error ejecutando esquema"
        exit 1
    fi
else
    echo "❌ Archivo schema.sql no encontrado"
    exit 1
fi

echo "🔍 Verificando tablas creadas..."
psql "$DB_URL" -c "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name IN ('empresas', 'obras', 'valorizaciones', 'representantes_legales');"

echo "🎉 ¡Configuración completada!"