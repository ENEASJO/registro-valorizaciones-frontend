#!/bin/bash
# Script para deploy manual a Cloud Run

PROJECT_ID="valoraciones-app-cloud-run"  # Tu project ID correcto
SERVICE_NAME="registro-valorizaciones-backend"
REGION="southamerica-west1"  # Región donde está tu servicio
COMMIT_SHA=$(git rev-parse HEAD)

echo "🚀 Iniciando deploy manual..."
echo "📦 Usando commit SHA: $COMMIT_SHA"

# Build y push de imagen usando cloudbuild.yaml
gcloud builds submit \
  --config backend/cloudbuild.yaml \
  --substitutions=COMMIT_SHA=$COMMIT_SHA \
  .

# Deploy a Cloud Run  
gcloud run deploy $SERVICE_NAME \
  --image gcr.io/$PROJECT_ID/$SERVICE_NAME:$COMMIT_SHA \
  --region=$REGION \
  --platform=managed \
  --allow-unauthenticated \
  --port=8080 \
  --memory=4Gi \
  --cpu=2 \
  --timeout=900s \
  --max-instances=10 \
  --set-env-vars PORT=8080,BROWSER_HEADLESS=true,PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1

echo "✅ Deploy completado!"
