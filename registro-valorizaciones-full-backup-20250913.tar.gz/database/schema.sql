-- Schema para registro-valorizaciones en Supabase
-- Creación de tablas para empresas, obras y valorizaciones

-- =====================================================
-- TABLA EMPRESAS
-- =====================================================
CREATE TABLE IF NOT EXISTS public.empresas (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    codigo TEXT UNIQUE NOT NULL,
    ruc TEXT UNIQUE NOT NULL,
    razon_social TEXT NOT NULL,
    nombre_comercial TEXT,
    email TEXT,
    telefono TEXT,
    celular TEXT,
    direccion TEXT,
    distrito TEXT,
    provincia TEXT,
    departamento TEXT,
    representante_legal TEXT,
    dni_representante TEXT,
    estado TEXT DEFAULT 'ACTIVO' CHECK (estado IN ('ACTIVO', 'INACTIVO', 'SUSPENDIDO')),
    tipo_empresa TEXT DEFAULT 'SAC',
    datos_sunat JSONB, -- Datos completos de SUNAT
    datos_osce JSONB,  -- Datos completos de OSCE  
    fuentes_consultadas TEXT[], -- Array de fuentes: ['SUNAT', 'OSCE']
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para optimizar consultas
CREATE INDEX IF NOT EXISTS idx_empresas_ruc ON public.empresas(ruc);
CREATE INDEX IF NOT EXISTS idx_empresas_codigo ON public.empresas(codigo);
CREATE INDEX IF NOT EXISTS idx_empresas_estado ON public.empresas(estado);
CREATE INDEX IF NOT EXISTS idx_empresas_created_at ON public.empresas(created_at DESC);

-- =====================================================
-- TABLA OBRAS
-- =====================================================
CREATE TABLE IF NOT EXISTS public.obras (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID NOT NULL REFERENCES public.empresas(id) ON DELETE CASCADE,
    codigo TEXT UNIQUE NOT NULL,
    nombre TEXT NOT NULL,
    descripcion TEXT,
    ubicacion TEXT,
    distrito TEXT,
    provincia TEXT,
    departamento TEXT,
    monto_contractual DECIMAL(15,2),
    fecha_inicio DATE,
    fecha_fin_programada DATE,
    fecha_fin_real DATE,
    estado TEXT DEFAULT 'EN_PROCESO' CHECK (estado IN ('EN_PROCESO', 'FINALIZADA', 'PARALIZADA', 'CANCELADA')),
    tipo_obra TEXT,
    modalidad_contrato TEXT,
    datos_osce JSONB, -- Datos del contrato desde OSCE
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para obras
CREATE INDEX IF NOT EXISTS idx_obras_empresa_id ON public.obras(empresa_id);
CREATE INDEX IF NOT EXISTS idx_obras_codigo ON public.obras(codigo);
CREATE INDEX IF NOT EXISTS idx_obras_estado ON public.obras(estado);
CREATE INDEX IF NOT EXISTS idx_obras_fecha_inicio ON public.obras(fecha_inicio);

-- =====================================================
-- TABLA VALORIZACIONES
-- =====================================================
CREATE TABLE IF NOT EXISTS public.valorizaciones (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    obra_id UUID NOT NULL REFERENCES public.obras(id) ON DELETE CASCADE,
    numero_valorizacion INTEGER NOT NULL,
    periodo_inicio DATE NOT NULL,
    periodo_fin DATE NOT NULL,
    fecha_presentacion DATE,
    fecha_aprobacion DATE,
    monto_valorizado DECIMAL(15,2) NOT NULL,
    monto_acumulado DECIMAL(15,2),
    porcentaje_avance DECIMAL(5,2),
    estado TEXT DEFAULT 'BORRADOR' CHECK (estado IN ('BORRADOR', 'PRESENTADA', 'APROBADA', 'RECHAZADA', 'PAGADA')),
    observaciones TEXT,
    archivos JSONB, -- Array de archivos adjuntos
    detalles JSONB, -- Detalles técnicos de la valorización
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- Constraint para evitar duplicados por obra
    UNIQUE(obra_id, numero_valorizacion)
);

-- Índices para valorizaciones
CREATE INDEX IF NOT EXISTS idx_valorizaciones_obra_id ON public.valorizaciones(obra_id);
CREATE INDEX IF NOT EXISTS idx_valorizaciones_estado ON public.valorizaciones(estado);
CREATE INDEX IF NOT EXISTS idx_valorizaciones_fecha_presentacion ON public.valorizaciones(fecha_presentacion);
CREATE INDEX IF NOT EXISTS idx_valorizaciones_numero ON public.valorizaciones(numero_valorizacion);

-- =====================================================
-- TABLA REPRESENTANTES LEGALES
-- =====================================================
CREATE TABLE IF NOT EXISTS public.representantes_legales (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID NOT NULL REFERENCES public.empresas(id) ON DELETE CASCADE,
    nombre TEXT NOT NULL,
    cargo TEXT NOT NULL,
    numero_documento TEXT,
    tipo_documento TEXT DEFAULT 'DNI' CHECK (tipo_documento IN ('DNI', 'CE', 'PASAPORTE')),
    telefono TEXT,
    email TEXT,
    desde DATE,
    hasta DATE,
    activo BOOLEAN DEFAULT true,
    fuente TEXT, -- 'SUNAT', 'OSCE', 'MANUAL'
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para representantes
CREATE INDEX IF NOT EXISTS idx_representantes_empresa_id ON public.representantes_legales(empresa_id);
CREATE INDEX IF NOT EXISTS idx_representantes_activo ON public.representantes_legales(activo);

-- =====================================================
-- FUNCIONES PARA ACTUALIZAR updated_at
-- =====================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para actualizar automáticamente updated_at
CREATE TRIGGER update_empresas_updated_at 
    BEFORE UPDATE ON public.empresas 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_obras_updated_at 
    BEFORE UPDATE ON public.obras 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_valorizaciones_updated_at 
    BEFORE UPDATE ON public.valorizaciones 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_representantes_updated_at 
    BEFORE UPDATE ON public.representantes_legales 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- RLS (Row Level Security) - OPCIONAL
-- =====================================================
-- Habilitar RLS si se necesita seguridad a nivel de fila
-- ALTER TABLE public.empresas ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.obras ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.valorizaciones ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.representantes_legales ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- VISTAS ÚTILES
-- =====================================================

-- Vista de empresas con conteo de obras
CREATE OR REPLACE VIEW public.empresas_resumen AS
SELECT 
    e.*,
    COUNT(o.id) as total_obras,
    COUNT(CASE WHEN o.estado = 'EN_PROCESO' THEN 1 END) as obras_activas,
    COALESCE(SUM(o.monto_contractual), 0) as monto_total_contratos
FROM public.empresas e
LEFT JOIN public.obras o ON e.id = o.empresa_id
GROUP BY e.id;

-- Vista de obras con información de empresa
CREATE OR REPLACE VIEW public.obras_detalle AS
SELECT 
    o.*,
    e.razon_social as empresa_razon_social,
    e.ruc as empresa_ruc,
    COUNT(v.id) as total_valorizaciones,
    COALESCE(SUM(v.monto_valorizado), 0) as monto_total_valorizado
FROM public.obras o
JOIN public.empresas e ON o.empresa_id = e.id
LEFT JOIN public.valorizaciones v ON o.id = v.obra_id
GROUP BY o.id, e.razon_social, e.ruc;

-- =====================================================
-- DATOS DE EJEMPLO (OPCIONAL)
-- =====================================================
-- Insertar empresa de ejemplo si no existe
INSERT INTO public.empresas (codigo, ruc, razon_social, estado, tipo_empresa) 
VALUES ('EMP206007', '20600074114', 'EMPRESA DE EJEMPLO SAC', 'ACTIVO', 'SAC')
ON CONFLICT (ruc) DO NOTHING;

-- =====================================================
-- COMENTARIOS EN TABLAS
-- =====================================================
COMMENT ON TABLE public.empresas IS 'Tabla principal de empresas con datos de SUNAT y OSCE';
COMMENT ON TABLE public.obras IS 'Obras/contratos asociados a empresas';
COMMENT ON TABLE public.valorizaciones IS 'Valorizaciones mensuales de avance de obra';
COMMENT ON TABLE public.representantes_legales IS 'Representantes legales de las empresas';

COMMENT ON COLUMN public.empresas.datos_sunat IS 'JSON con datos completos obtenidos de SUNAT';
COMMENT ON COLUMN public.empresas.datos_osce IS 'JSON con datos completos obtenidos de OSCE';
COMMENT ON COLUMN public.empresas.fuentes_consultadas IS 'Array de fuentes consultadas: SUNAT, OSCE';